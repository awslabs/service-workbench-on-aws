---
id: introduction
title: Projects Introduction
sidebar_label: Introduction
---

A Project is a logical grouping of resources that users have access to. In order for a Researcher to upload their own Study data sets and to deploy and user Workspaces a user must have access to a Project.

Projects must be associated to an [**Index**](/user_guide/sidebar/admin/accounts/indexes/introduction). A Project can only be associated to single [**Index**](/user_guide/sidebar/admin/accounts/indexes/introduction).
