---
id: introduction
title: Indexes Introduction
sidebar_label: Introduction
---

Indexes are a mechanism of grouping [**Projects**](../projects/introduction) together for cost reporting purposes. There can be many [**Projects**](../projects/introduction) associated with a single Index. There can only be a single AWS Account associated with an Index.
